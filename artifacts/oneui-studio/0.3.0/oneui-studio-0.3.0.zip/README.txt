One UI Studio 0.3.0 native prototype

Extract oneui-studio.apk and install with Android's package installer on Android 17/API 37. This is a source editor; it does not install or enable overlays. Read apps/oneui-studio/README.md for the implemented behavior, manual smoke test and offline build command.

Sources, bundled assets, the offline builder and opt-in portable host/build checks are included. Prepare SDK/JDK/tools, JSON-java test dependency, a licensed test font and your own development key separately; none are downloaded by the included builders or checks.

Evidence is under generated/oneui-studio/0.3.0/. Host and packaging checks passed; the APK has not been installed or run on a phone/emulator. Firmware APKs and signing keys are excluded.

Repository: https://github.com/Bingblop/oneui-theme-engine
Draft PR: https://github.com/Bingblop/oneui-theme-engine/pull/2
Continue from docs/AGENT_HANDOFF.md on branch design/oneui9-studio.
