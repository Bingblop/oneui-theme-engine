Native One UI Studio source-to-overlay integration example

Target: SM-S948U1, Android17/API37, CP2A.260605.016.S948U1UEU4BZID.

source/neon-violet-edited-native.ouitheme was exported by the exact production Studio0.3.0 codec on the host with Android stubs. Both variants, per-app SystemUI/Settings colors and20dp dark/16dp light corners were compiled against the supplied target APKs.

Exactly three final developer-signed overlays are in compiled/targets/{framework,systemui,settings}/overlay-signed.apk. Generated projects and readback/signature reports are in generated/oneui9/native-export-0.3.0/. The edited example retains the original Neon source ID/version and overlay package identities; treat it as a replacement example. It has not been installed or applied on a phone.

Current stdlib compiler/helper/sync and80-passing host tests are included. Read docs/design/native-source-to-overlays.md for direct .ouitheme compilation and docs/design/studio-asset-sync.md for read-only asset reproduction. Native APK and detailed research downloads remain separate, linked from the GitHub branch.

Original Samsung APKs, toolchain binaries, JSON dependency, fonts and signing keys are excluded. Supply verified input APKs/tools and your own development key for a rebuild.

Repository: https://github.com/Bingblop/oneui-theme-engine
PR: https://github.com/Bingblop/oneui-theme-engine/pull/2
Branch: design/oneui9-studio
Continuation: docs/AGENT_HANDOFF.md
